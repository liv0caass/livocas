  createCanvas(100, 100, WEBGL);

  describe('A white square spins around on gray canvas.');
}

function draw() {
  background(200);

  // Rotate around the y-axis.
  rotateY(frameCount * 0.01);

  // Draw the rectangle.
function setup() {
  rect(-20, -30, 55, 55);
}